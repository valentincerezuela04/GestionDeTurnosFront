export enum TipoPago {

    EFECTIVO = 'EFECTIVO',
    MERCADO_PAGO = 'MERCADO_PAGO',

}
