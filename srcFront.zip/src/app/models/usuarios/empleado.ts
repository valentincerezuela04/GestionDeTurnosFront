import { Usuario } from "./usuario";

export interface Empleado extends Usuario {

    legajo: string,

}
