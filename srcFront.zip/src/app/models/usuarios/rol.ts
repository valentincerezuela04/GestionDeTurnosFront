export enum Rol {
  ADMIN = 'ADMIN',
  EMPLEADO = 'EMPLEADO',
  CLIENTE = 'CLIENTE'
}





