// src/app/core/services/reserva.service.ts
import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_CONFIG } from '../../config/API';

import {
  ReservaRequestByClienteDTO,
  ReservaRequestByEmpleadoDTO,
  ReservaUpdateRequestDTO,
  ReservaResponseDTO
} from '../../dto/Reserva';

@Injectable({ providedIn: 'root' })
export class ReservaService {
  // Mantengo el mismo nombre y compatibilidad con V1.
  // Lo dejo público como en V1, pero readonly para evitar sobrescrituras accidentales.
  readonly baseUrl = `${API_CONFIG.baseUrl}/reserva`;

  // Inyección igual que en V1 (compatibilidad)
  private readonly http = inject(HttpClient);


   getHistorialCliente(clienteId: number): Observable<ReservaResponseDTO[]> {
    return this.http.get<ReservaResponseDTO[]>(
      `${this.baseUrl}/historial/${clienteId}`,
      { withCredentials: true }
    );
  }


  getHistorialGeneral(): Observable<ReservaResponseDTO[]> {
    return this.http.get<ReservaResponseDTO[]>(
      `${this.baseUrl}/historial`,
      { withCredentials: true }
    );
  }

  // READ: todas las reservas activas según el rol del usuario
  getReservasActivas(): Observable<ReservaResponseDTO[]> {
    return this.http.get<ReservaResponseDTO[]>(`${this.baseUrl}/all/activas`);
  }

  // CREATE: cliente logueado crea su reserva
  createReservaCliente(dto: ReservaRequestByClienteDTO): Observable<ReservaResponseDTO> {
    return this.http.post<ReservaResponseDTO>(`${this.baseUrl}/crear`, dto);
  }

  // CREATE: empleado crea una reserva para un cliente
  createReservaEmpleado(dto: ReservaRequestByEmpleadoDTO): Observable<ReservaResponseDTO> {
    return this.http.post<ReservaResponseDTO>(`${this.baseUrl}/crear/by-empleado`, dto);
  }

  // UPDATE: cliente actualiza su reserva
  updateReservaCliente(dto: ReservaUpdateRequestDTO): Observable<ReservaResponseDTO> {
    return this.http.put<ReservaResponseDTO>(`${this.baseUrl}/update`, dto);
  }

  // UPDATE: empleado actualiza una reserva
  updateReservaEmpleado(dto: ReservaUpdateRequestDTO): Observable<ReservaResponseDTO> {
    return this.http.put<ReservaResponseDTO>(`${this.baseUrl}/update/by-empleado`, dto);
  }

  // CANCELAR: cliente cancela su reserva
  cancelarReservaCliente(id: number): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}/cancelar`, null);
  }

  // CANCELAR: empleado cancela una reserva
  cancelarReservaEmpleado(id: number): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}/cancelar/by-empleado`, null);
  }

  // DELETE: eliminar reserva (ej: admin)
  deleteReserva(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/eliminar/${id}`, {
      responseType: 'text' as 'json'
    });
  }

  // DELETE: limpiar historial completo (solo admin)
  clearHistorial(): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/historial`, {
      withCredentials: true,
      responseType: 'text' as 'json'
    });
  }


   generarLinkPago(reservaId: number): Observable<{ initPoint: string }> {
    return this.http.post<{ initPoint: string }>(
      `${this.baseUrl}/${reservaId}/pago/mercado-pago`,
      {}
    );
  }

  confirmarPago(reservaId: number): Observable<void> {
  return this.http.put<void>(`${this.baseUrl}/${reservaId}/confirmar-pago`, null);
}

}
