// src/app/dto/reserva/index.ts   (barrel para imports limpios)
// src/app/dto/Reserva/index.ts
export { ReservaRequestByClienteDTO }   from './reservaRequestbyClienteDTO';
export { ReservaRequestByEmpleadoDTO }  from './reservaRequestbyEmpleadoDTO ';
export { ReservaUpdateRequestDTO }      from './reservaUpdateRequestDTO ';
export { ReservaResponseDTO }           from './reservaResponseDTO';
export { ReservaResponseEnSalaDTO }     from './reservaResponseenSalaDTO'; 